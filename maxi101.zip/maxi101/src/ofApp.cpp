#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0);
    ofSetFrameRate(30);
    
    sampleRate = 44100;
    bufferSize = 512;
    
    //!!!!!!!!!!!!!!!!!MAXIMIN SETTING!!!!!!!!!!!!!!!!!!
    // settings for ofxMaxim.
    maxiSettings::setup(sampleRate, 2, bufferSize);
    //sets up the soundStream object with default devices
    auto devices = soundStream.getMatchingDevices("default");
    //you can also list input/output devices with soundStream.printDeviceList()
    soundSettings.setOutListener(this);
    soundSettings.sampleRate = sampleRate;
    soundSettings.numOutputChannels = 2;
    soundSettings.numInputChannels = 0; // change to "2" if the programme crashes
    soundSettings.bufferSize = bufferSize;
    soundStream.setup(soundSettings);
    
    
    
    //!!!!!!SET TIMER!!!!!!
      myClock.setTicksPerBeat(1);//This sets the number of ticks per beat
      myClock.setTempo(120);// This sets the tempo in Beats Per Minute
      tim = 1;
    
    //GUI BUTTONS
    gui.setup();
    gui2.setup();
    gui3.setup();
    gui4.setup();
    gui5.setup();
    gui6.setup();
    gui7.setup();
    
    gui.setPosition(0,100);
    gui2.setPosition(200,100);
    gui3.setPosition(400,100);
    gui4.setPosition(600,100);
    gui5.setPosition(800,100);
    gui6.setPosition(1000,100);
    gui7.setPosition(1200,100);
    
    //GUI FOR MERCURY
    gui.add(mercuryAries.setup("mercury in aries"));
    gui.add(mercuryTaurus.setup("mercury in taurus"));
    gui.add(mercuryGemini.setup("mercury in gemini"));
    gui.add(mercuryCancer.setup("mercury in cancer"));
    gui.add(mercuryLeo.setup("mercury in leo"));
    gui.add(mercuryVirgo.setup("mercury in virgo"));
    gui.add(mercuryLibra.setup("mercury in libra"));
    gui.add(mercuryScorpio.setup("mercury in scorpio"));
    gui.add(mercurySagittarius.setup("mercury in sagittarius"));
    gui.add(mercuryCapricorn.setup("mercury in capricorn"));
    gui.add(mercuryAquarius.setup("mercury in aquarius"));
    gui.add(mercuryPieces.setup("mercury in pieces"));

    mercuryAries.addListener(this, &ofApp::mercuryAriesPressed);
    mercuryTaurus.addListener(this, &ofApp::mercuryTaurusPressed);
    mercuryGemini.addListener(this, &ofApp::mercuryGeminiPressed);
    mercuryCancer.addListener(this, &ofApp::mercuryCancerPressed);
    mercuryLeo.addListener(this, &ofApp::mercuryLeoPressed);
    mercuryVirgo.addListener(this, &ofApp::mercuryVirgoPressed);
    mercuryLibra.addListener(this, &ofApp::mercuryLibraPressed);
    mercuryScorpio.addListener(this, &ofApp::mercuryScorpioPressed);
    mercurySagittarius.addListener(this, &::ofApp::mercurySagitariusPressed);
    mercuryCapricorn.addListener(this, &ofApp::mercuryCapricornPressed);
    mercuryAquarius.addListener(this, &ofApp::mercuryAquariusPressed);
    mercuryPieces.addListener(this, &ofApp::mercuryPiecesPressed);
    
    
    //GUI FOR VENUS
    gui2.add(venusAries.setup("venus in aries"));
      gui2.add(venusTaurus.setup("venus in taurus"));
      gui2.add(venusGemini.setup("venus in gemini"));
      gui2.add(venusCancer.setup("venus in cancer"));
      gui2.add(venusLeo.setup("venus in leo"));
      gui2.add(venusVirgo.setup("venus in virgo"));
      gui2.add(venusLibra.setup("venus in libra"));
      gui2.add(venusScorpio.setup("venus in scorpio"));
      gui2.add(venusSagittarius.setup("venus in sagittarius"));
      gui2.add(venusCapricorn.setup("venus in capricorn"));
      gui2.add(venusAquarius.setup("venus in aquarius"));
      gui2.add(venusPieces.setup("venus in pieces"));

      venusAries.addListener(this, &ofApp::venusAriesPressed);
      venusTaurus.addListener(this, &ofApp::venusTaurusPressed);
      venusGemini.addListener(this, &ofApp::venusGeminiPressed);
      venusCancer.addListener(this, &ofApp::venusCancerPressed);
      venusLeo.addListener(this, &ofApp::venusLeoPressed);
      venusVirgo.addListener(this, &ofApp::venusVirgoPressed);
      venusLibra.addListener(this, &ofApp::venusLibraPressed);
    
    //GUI SET-UP FOR MARS
    gui3.add(marsAries.setup("mars in aries"));
      gui3.add(marsTaurus.setup("mars in taurus"));
      gui3.add(marsGemini.setup("mars in gemini"));
      gui3.add(marsCancer.setup("mars in cancer"));
      gui3.add(marsLeo.setup("mars in leo"));
      gui3.add(marsVirgo.setup("mars in virgo"));
      gui3.add(marsLibra.setup("mars in libra"));
      gui3.add(marsScorpio.setup("mars in scorpio"));
      gui3.add(marsSagittarius.setup("mars in sagittarius"));
      gui3.add(marsCapricorn.setup("mars in capricorn"));
      gui3.add(marsAquarius.setup("mars in aquarius"));
      gui3.add(marsPieces.setup("mars in pieces"));
      marsAries.addListener(this, &ofApp::marsAriesPressed);
      marsTaurus.addListener(this, &ofApp::marsTaurusPressed);
      marsGemini.addListener(this, &ofApp::marsGeminiPressed);
      marsCancer.addListener(this, &ofApp::marsCancerPressed);
      marsLeo.addListener(this, &ofApp::marsLeoPressed);
      marsVirgo.addListener(this, &ofApp::marsVirgoPressed);
      marsLibra.addListener(this, &ofApp::marsLibraPressed);
      marsScorpio.addListener(this, &ofApp::marsScorpioPressed);
      marsSagittarius.addListener(this, &::ofApp::marsSagitariusPressed);
      marsCapricorn.addListener(this, &ofApp::marsCapricornPressed);
      marsAquarius.addListener(this, &ofApp::marsAquariusPressed);
      marsPieces.addListener(this, &ofApp::marsPiecesPressed);

    //GUI SET UP FOR JUPITER
       gui4.add(jupiterAries.setup("jupiter in aries"));
        gui4.add(jupiterTaurus.setup("jupiter in taurus"));
        gui4.add(jupiterGemini.setup("jupiter in gemini"));
        gui4.add(jupiterCancer.setup("jupiter in cancer"));
        gui4.add(jupiterLeo.setup("jupiter in leo"));
        gui4.add(jupiterVirgo.setup("jupiter in virgo"));
        gui4.add(jupiterLibra.setup("jupiter in libra"));
        gui4.add(jupiterScorpio.setup("jupiter in scorpio"));
        gui4.add(jupiterSagittarius.setup("jupiter in sagittarius"));
        gui4.add(jupiterCapricorn.setup("jupiter in capricorn"));
        gui4.add(jupiterAquarius.setup("jupiter in aquarius"));
        gui4.add(jupiterPieces.setup("jupiter in pieces"));
        jupiterAries.addListener(this, &ofApp::jupiterAriesPressed);
        jupiterTaurus.addListener(this, &ofApp::jupiterTaurusPressed);
        jupiterGemini.addListener(this, &ofApp::jupiterGeminiPressed);
        jupiterCancer.addListener(this, &ofApp::jupiterCancerPressed);
        jupiterLeo.addListener(this, &ofApp::jupiterLeoPressed);
        jupiterVirgo.addListener(this, &ofApp::jupiterVirgoPressed);
        jupiterLibra.addListener(this, &ofApp::jupiterLibraPressed);
        jupiterScorpio.addListener(this, &ofApp::jupiterScorpioPressed);
        jupiterSagittarius.addListener(this, &::ofApp::jupiterSagitariusPressed);
        jupiterCapricorn.addListener(this, &ofApp::jupiterCapricornPressed);
        jupiterAquarius.addListener(this, &ofApp::jupiterAquariusPressed);
        jupiterPieces.addListener(this, &ofApp::jupiterPiecesPressed);
        
    //GUI SET UP
       gui5.add(saturnAries.setup("saturn in aries"));
        gui5.add(saturnTaurus.setup("saturn in taurus"));
        gui5.add(saturnGemini.setup("saturn in gemini"));
        gui5.add(saturnCancer.setup("saturn in cancer"));
        gui5.add(saturnLeo.setup("saturn in leo"));
        gui5.add(saturnVirgo.setup("saturn in virgo"));
        gui5.add(saturnLibra.setup("saturn in libra"));
        gui5.add(saturnScorpio.setup("saturn in scorpio"));
        gui5.add(saturnSagittarius.setup("saturn in sagittarius"));
        gui5.add(saturnCapricorn.setup("saturn in capricorn"));
        gui5.add(saturnAquarius.setup("saturn in aquarius"));
        gui5.add(saturnPieces.setup("saturn in pieces"));
        saturnAries.addListener(this, &ofApp::saturnAriesPressed);
        saturnTaurus.addListener(this, &ofApp::saturnTaurusPressed);
        saturnGemini.addListener(this, &ofApp::saturnGeminiPressed);
        saturnCancer.addListener(this, &ofApp::saturnCancerPressed);
        saturnLeo.addListener(this, &ofApp::saturnLeoPressed);
        saturnVirgo.addListener(this, &ofApp::saturnVirgoPressed);
        saturnLibra.addListener(this, &ofApp::saturnLibraPressed);
        saturnScorpio.addListener(this, &ofApp::saturnScorpioPressed);
        saturnSagittarius.addListener(this, &::ofApp::saturnSagitariusPressed);
        saturnCapricorn.addListener(this, &ofApp::saturnCapricornPressed);
        saturnAquarius.addListener(this, &ofApp::saturnAquariusPressed);
        saturnPieces.addListener(this, &ofApp::saturnPiecesPressed);

    
    //GUI SET UP
       gui6.add(uranusAries.setup("uranus in aries"));
        gui6.add(uranusTaurus.setup("uranus in taurus"));
        gui6.add(uranusGemini.setup("uranus in gemini"));
        gui6.add(uranusCancer.setup("uranus in cancer"));
        gui6.add(uranusLeo.setup("uranus in leo"));
        gui6.add(uranusVirgo.setup("uranus in virgo"));
        gui6.add(uranusLibra.setup("uranus in libra"));
        gui6.add(uranusScorpio.setup("uranus in scorpio"));
        gui6.add(uranusSagittarius.setup("uranus in sagittarius"));
        gui6.add(uranusCapricorn.setup("uranus in capricorn"));
        gui6.add(uranusAquarius.setup("uranus in aquarius"));
        gui6.add(uranusPieces.setup("uranus in pieces"));
        uranusAries.addListener(this, &ofApp::uranusAriesPressed);
        uranusTaurus.addListener(this, &ofApp::uranusTaurusPressed);
        uranusGemini.addListener(this, &ofApp::uranusGeminiPressed);
        uranusCancer.addListener(this, &ofApp::uranusCancerPressed);
        uranusLeo.addListener(this, &ofApp::uranusLeoPressed);
        uranusVirgo.addListener(this, &ofApp::uranusVirgoPressed);
        uranusLibra.addListener(this, &ofApp::uranusLibraPressed);
        uranusScorpio.addListener(this, &ofApp::uranusScorpioPressed);
        uranusSagittarius.addListener(this, &::ofApp::uranusSagitariusPressed);
        uranusCapricorn.addListener(this, &ofApp::uranusCapricornPressed);
        uranusAquarius.addListener(this, &ofApp::uranusAquariusPressed);
        uranusPieces.addListener(this, &ofApp::uranusPiecesPressed);
        
    //GUI SET UP
       gui7.add(neptuneAries.setup("neptune in aries"));
        gui7.add(neptuneTaurus.setup("neptune in taurus"));
        gui7.add(neptuneGemini.setup("neptune in gemini"));
        gui7.add(neptuneCancer.setup("neptune in cancer"));
        gui7.add(neptuneLeo.setup("neptune in leo"));
        gui7.add(neptuneVirgo.setup("neptune in virgo"));
        gui7.add(neptuneLibra.setup("neptune in libra"));
        gui7.add(neptuneScorpio.setup("neptune in scorpio"));
        gui7.add(neptuneSagittarius.setup("neptune in sagittarius"));
        gui7.add(neptuneCapricorn.setup("neptune in capricorn"));
        gui7.add(neptuneAquarius.setup("neptune in aquarius"));
        gui7.add(neptunePieces.setup("neptune in pieces"));
        neptuneAries.addListener(this, &ofApp::neptuneAriesPressed);
        neptuneTaurus.addListener(this, &ofApp::neptuneTaurusPressed);
        neptuneGemini.addListener(this, &ofApp::neptuneGeminiPressed);
        neptuneCancer.addListener(this, &ofApp::neptuneCancerPressed);
        neptuneLeo.addListener(this, &ofApp::neptuneLeoPressed);
        neptuneVirgo.addListener(this, &ofApp::neptuneVirgoPressed);
        neptuneLibra.addListener(this, &ofApp::neptuneLibraPressed);
        neptuneScorpio.addListener(this, &ofApp::neptuneScorpioPressed);
        neptuneSagittarius.addListener(this, &::ofApp::neptuneSagitariusPressed);
        neptuneCapricorn.addListener(this, &ofApp::neptuneCapricornPressed);
        neptuneAquarius.addListener(this, &ofApp::neptuneAquariusPressed);
        neptunePieces.addListener(this, &ofApp::neptunePiecesPressed);
        

    
    //oscillator status
    mercuryStatus == 0;
    venusStatus == 0;
    marsStatus == 0;
    jupiterStatus == 0;
    saturnStatus == 0;
    uranusStatus == 0;
    neptuneStatus == 0;
    
    
    
    
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
 
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetColor(255, 255, 255);
    ofDrawBitmapString("Sonar Cosmia - astrological sonification in C++ - written by Malu Laet 7/2k23 ",5,20);
    ofDrawBitmapString("An on going project, where cosmic data is transformed into sound signals. ", 5,40);
    ofDrawBitmapString(" Click in your planet + star sign combination to listen to the sky when you where born. ", 0,80);
    
    
//    ofDrawBitmapString("taurus ", 0,30);
//    ofDrawBitmapString("gemini ", 0,40);
//    ofDrawBitmapString("cancer ", 0,50);
//    ofDrawBitmapString("leo ", 0,60);
//    ofDrawBitmapString("virgo ", 0,70);
//    ofDrawBitmapString("libra ", 0,80);
//    ofDrawBitmapString("sagittarius ", 0,90);
//    ofDrawBitmapString("aquarius ", 0,100);
//    ofDrawBitmapString("pieces ", 0,110);
//
    gui.draw();
    gui2.draw();
    gui3.draw();
    gui4.draw();
    gui5.draw();
    gui6.draw();
    gui7.draw();
}
//--------------------------------------------------------------
void ofApp::exit() {
    ofSoundStreamClose();
    ofSoundStreamStop();
}
//--------------------------------------------------------------
void ofApp::audioOut(ofSoundBuffer & buffer){
    
   
    
    
    
    for (unsigned int i = 0; i < buffer.getNumFrames(); i++) { //loop through the
        //double wave;
        //wave = osc1.sinewave(440);
    
    
        double myMercury;
        double myMercuryFiltered;
               
        double myVenus;
        double myVenusFiltered;

        double myMars;
        double myMarsFiltered;

        double myJupiter;
        double myJupiterFiltered;
               
        double mySaturn;
        double mySaturnFiltered;

        double myUranus;
        double myUranusFiltered;
               
        double myNeptune;
        double myNeptuneFiltered;

        
        //!!!!!!!!!!!!!MERCURY!!!!!!!!!

        if (mercuryStatus == 1){//MERCURY ARIES
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*aries)) + sign.sinewave(aries+(period2.sinewave(mercuryPeriod)*mercury));

            }
        
        if (mercuryStatus == 2){//MERCURY TAURUS
                
            myMercury=planet.sinewave(mercury+(sign.sinewave(mercuryPeriod)*taurus));
            
            }

        if (mercuryStatus == 3){//MERCURY GEMINI
                
            myMercury=planet.sinewave(mercury+(sign.sinewave(mercuryPeriod)*gemini)) + sign.sinewave(gemini+(planet.sinewave(mercuryPeriod)*mercury));
            }
        
        if (mercuryStatus == 4){//MERCURY CANCER
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*cancer)) + sign.sinewave(cancer+(period2.sinewave(mercuryPeriod)*mercury));

            }
        
        if (mercuryStatus == 5){//MERCURY LEO
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*leo)) + sign.sinewave(leo+(period2.sinewave(mercuryPeriod)*mercury));

            }
        
        if (mercuryStatus == 6){//MERCURY VIRGO
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*virgo)) + sign.sinewave(virgo+(period2.sinewave(mercuryPeriod)*mercury));

            }
        
        if (mercuryStatus == 7){//MERCURY LIBRA
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*libra)) + sign.sinewave(libra+(period2.sinewave(mercuryPeriod)*mercury));

            }
    
        if (mercuryStatus == 8){//MERCURY SCORPIO
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*scorpio)) + sign.sinewave(scorpio+(period2.sinewave(mercuryPeriod)*mercury));

            }
        
        if (mercuryStatus == 9){//MERCURY SAGITTARIUS
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*sagittarius)) + sign.sinewave(sagittarius+(period2.sinewave(mercuryPeriod)*mercury));

            }
        
        if (mercuryStatus == 10){//MERCURY CAPRICORN
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*capricorn)) + sign.sinewave(capricorn+(period2.sinewave(mercuryPeriod)*mercury));

            }
        
        if (mercuryStatus == 11){//MERCURY AQUARIUS
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*aquarius)) + sign.sinewave(aquarius+(period2.sinewave(mercuryPeriod)*mercury));

            }
    
        
        
        if (mercuryStatus == 12){//MERCURY PIECES
                
            myMercury=planet.sinewave(mercury+(period.sinewave(mercuryPeriod)*pieces)) + sign.sinewave(pieces+(period2.sinewave(mercuryPeriod)*mercury));

            }
        

    
        myMercuryFiltered = myFilter.hires(myMercury, 0.6,10.0);

        //!!!!!!!!!!!!!Venus!!!!!!!!!

          if (venusStatus == 1){//Venus ARIES
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*aries)) + sign.sinewave(aries+(period2.sinewave(venusPeriod)*venus));

              }
          
          if (venusStatus == 2){//Venus TAURUS
                  
              myVenus=planet.sinewave(venus+(sign.sinewave(venusPeriod)*taurus));
              
              }

          if (venusStatus == 3){//Venus GEMINI
                  
              myVenus=planet.sinewave(venus+(sign.sinewave(venusPeriod)*gemini)) + sign.sinewave(gemini+(planet.sinewave(venusPeriod)*venus));
              }
          
          if (venusStatus == 4){//Venus CANCER
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*cancer)) + sign.sinewave(cancer+(period2.sinewave(venusPeriod)*venus));

              }
          
          if (venusStatus == 5){//Venus LEO
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*leo)) + sign.sinewave(leo+(period2.sinewave(venusPeriod)*venus));

              }
          
          if (venusStatus == 6){//Venus VIRGO
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*virgo)) + sign.sinewave(virgo+(period2.sinewave(venusPeriod)*venus));

              }
          
          if (venusStatus == 7){//Venus LIBRA
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*libra)) + sign.sinewave(libra+(period2.sinewave(venusPeriod)*venus));

              }
      
          if (venusStatus == 8){//Venus SCORPIO
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*scorpio)) + sign.sinewave(scorpio+(period2.sinewave(venusPeriod)*venus));

              }
          
          if (venusStatus == 9){//Venus SAGITTARIUS
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*sagittarius)) + sign.sinewave(sagittarius+(period2.sinewave(venusPeriod)*venus));

              }
          
          if (venusStatus == 10){//Venus CAPRICORN
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*capricorn)) + sign.sinewave(capricorn+(period2.sinewave(venusPeriod)*venus));

              }
          
          if (venusStatus == 11){//Venus AQUARIUS
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*aquarius)) + sign.sinewave(aquarius+(period2.sinewave(venusPeriod)*venus));

              }
      
          
          
          if (venusStatus == 12){//Venus PIECES
                  
              myVenus=planet.sinewave(venus+(period.sinewave(venusPeriod)*pieces)) + sign.sinewave(pieces+(period2.sinewave(venusPeriod)*venus));

              }
          
      
          myVenusFiltered = myFilter.hires(myVenus, 0.6,10.0);

        //OSCILLATOR MARS

                if (marsStatus == 1){//Mars ARIES
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*aries)) + sign.sinewave(aries+(period2.sinewave(marsPeriod)*mars));

                    }
                
                if (marsStatus == 2){//Mars TAURUS
                        
                    myMars=planet.sinewave(mars+(sign.sinewave(marsPeriod)*taurus));
                    
                    }

                if (marsStatus == 3){//Mars GEMINI
                        
                    myMars=planet.sinewave(mars+(sign.sinewave(marsPeriod)*gemini)) + sign.sinewave(gemini+(planet.sinewave(marsPeriod)*mars));
                    }
                
                if (marsStatus == 4){//Mars CANCER
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*cancer)) + sign.sinewave(cancer+(period2.sinewave(marsPeriod)*mars));

                    }
                
                if (marsStatus == 5){//Mars LEO
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*leo)) + sign.sinewave(leo+(period2.sinewave(marsPeriod)*mars));

                    }
                
                if (marsStatus == 6){//Mars VIRGO
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*virgo)) + sign.sinewave(virgo+(period2.sinewave(marsPeriod)*mars));

                    }
                
                if (marsStatus == 7){//Mars LIBRA
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*libra)) + sign.sinewave(libra+(period2.sinewave(marsPeriod)*mars));

                    }
            
                if (marsStatus == 8){//Mars SCORPIO
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*scorpio)) + sign.sinewave(scorpio+(period2.sinewave(marsPeriod)*mars));

                    }
                
                if (marsStatus == 9){//Mars SAGITTARIUS
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*sagittarius)) + sign.sinewave(sagittarius+(period2.sinewave(marsPeriod)*mars));

                    }
                
                if (marsStatus == 10){//Mars CAPRICORN
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*capricorn)) + sign.sinewave(capricorn+(period2.sinewave(marsPeriod)*mars));

                    }
                
                if (marsStatus == 11){//Mars AQUARIUS
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*aquarius)) + sign.sinewave(aquarius+(period2.sinewave(marsPeriod)*mars));

                    }
            
                
                
                if (marsStatus == 12){//Mars PIECES
                        
                    myMars=planet.sinewave(mars+(period.sinewave(marsPeriod)*pieces)) + sign.sinewave(pieces+(period2.sinewave(marsPeriod)*mars));

                    }
                
            
                myMarsFiltered = myFilter.hires(myMars, 0.6,10.0);

        //OSCILLATOR Jupiter

                if (jupiterStatus == 1){//Jupiter ARIES
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*aries)) + sign.sinewave(aries+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
                
                if (jupiterStatus == 2){//Jupiter TAURUS
                        
                    myJupiter=planet.sinewave(jupiter+(sign.sinewave(jupiterPeriod)*taurus));
                    
                    }

                if (jupiterStatus == 3){//Jupiter GEMINI
                        
                    myJupiter=planet.sinewave(jupiter+(sign.sinewave(jupiterPeriod)*gemini)) + sign.sinewave(gemini+(planet.sinewave(jupiterPeriod)*jupiter));
                    }
                
                if (jupiterStatus == 4){//Jupiter CANCER
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*cancer)) + sign.sinewave(cancer+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
                
                if (jupiterStatus == 5){//Jupiter LEO
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*leo)) + sign.sinewave(leo+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
                
                if (jupiterStatus == 6){//Jupiter VIRGO
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*virgo)) + sign.sinewave(virgo+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
                
                if (jupiterStatus == 7){//Jupiter LIBRA
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*libra)) + sign.sinewave(libra+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
            
                if (jupiterStatus == 8){//Jupiter SCORPIO
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*scorpio)) + sign.sinewave(scorpio+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
                
                if (jupiterStatus == 9){//Jupiter SAGITTARIUS
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*sagittarius)) + sign.sinewave(sagittarius+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
                
                if (jupiterStatus == 10){//Jupiter CAPRICORN
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*capricorn)) + sign.sinewave(capricorn+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
                
                if (jupiterStatus == 11){//Jupiter AQUARIUS
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*aquarius)) + sign.sinewave(aquarius+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
            
                
                
                if (jupiterStatus == 12){//Jupiter PIECES
                        
                    myJupiter=planet.sinewave(jupiter+(period.sinewave(jupiterPeriod)*pieces)) + sign.sinewave(pieces+(period2.sinewave(jupiterPeriod)*jupiter));

                    }
        
        myJupiterFiltered = myFilter.hires(myJupiter, 0.6,10.0);

        //OSCILLATOR Saturn

                if (saturnStatus == 1){//Saturn ARIES
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*aries)) + sign.sinewave(aries+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
                if (saturnStatus == 2){//Saturn TAURUS
                        
                    mySaturn=planet.sinewave(saturn+(sign.sinewave(saturnPeriod)*taurus));
                    
                    }

                if (saturnStatus == 3){//Saturn GEMINI
                        
                    mySaturn=planet.sinewave(saturn+(sign.sinewave(saturnPeriod)*gemini)) + sign.sinewave(gemini+(planet.sinewave(saturnPeriod)*saturn));
                    }
                
                if (saturnStatus == 4){//Saturn CANCER
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*cancer)) + sign.sinewave(cancer+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
                if (saturnStatus == 5){//Saturn LEO
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*leo)) + sign.sinewave(leo+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
                if (saturnStatus == 6){//Saturn VIRGO
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*virgo)) + sign.sinewave(virgo+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
                if (saturnStatus == 7){//Saturn LIBRA
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*libra)) + sign.sinewave(libra+(period2.sinewave(saturnPeriod)*saturn));

                    }
            
                if (saturnStatus == 8){//Saturn SCORPIO
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*scorpio)) + sign.sinewave(scorpio+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
                if (saturnStatus == 9){//Saturn SAGITTARIUS
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*sagittarius)) + sign.sinewave(sagittarius+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
                if (saturnStatus == 10){//Saturn CAPRICORN
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*capricorn)) + sign.sinewave(capricorn+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
                if (saturnStatus == 11){//Saturn AQUARIUS
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*aquarius)) + sign.sinewave(aquarius+(period2.sinewave(saturnPeriod)*saturn));

                    }
            
                
                
                if (saturnStatus == 12){//Saturn PIECES
                        
                    mySaturn=planet.sinewave(saturn+(period.sinewave(saturnPeriod)*pieces)) + sign.sinewave(pieces+(period2.sinewave(saturnPeriod)*saturn));

                    }
                
            
                mySaturnFiltered = myFilter.hires(mySaturn, 0.6,10.0);
    
        
        //OSCILLATOR Uranus

                if (uranusStatus == 1){//Uranus ARIES
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*aries)) + sign.sinewave(aries+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
                if (uranusStatus == 2){//Uranus TAURUS
                        
                    myUranus=planet.sinewave(uranus+(sign.sinewave(uranusPeriod)*taurus));
                    
                    }

                if (uranusStatus == 3){//Uranus GEMINI
                        
                    myUranus=planet.sinewave(uranus+(sign.sinewave(uranusPeriod)*gemini)) + sign.sinewave(gemini+(planet.sinewave(uranusPeriod)*uranus));
                    }
                
                if (uranusStatus == 4){//Uranus CANCER
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*cancer)) + sign.sinewave(cancer+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
                if (uranusStatus == 5){//Uranus LEO
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*leo)) + sign.sinewave(leo+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
                if (uranusStatus == 6){//Uranus VIRGO
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*virgo)) + sign.sinewave(virgo+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
                if (uranusStatus == 7){//Uranus LIBRA
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*libra)) + sign.sinewave(libra+(period2.sinewave(uranusPeriod)*uranus));

                    }
            
                if (uranusStatus == 8){//Uranus SCORPIO
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*scorpio)) + sign.sinewave(scorpio+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
                if (uranusStatus == 9){//Uranus SAGITTARIUS
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*sagittarius)) + sign.sinewave(sagittarius+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
                if (uranusStatus == 10){//Uranus CAPRICORN
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*capricorn)) + sign.sinewave(capricorn+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
                if (uranusStatus == 11){//Uranus AQUARIUS
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*aquarius)) + sign.sinewave(aquarius+(period2.sinewave(uranusPeriod)*uranus));

                    }
            
                
                
                if (uranusStatus == 12){//Uranus PIECES
                        
                    myUranus=planet.sinewave(uranus+(period.sinewave(uranusPeriod)*pieces)) + sign.sinewave(pieces+(period2.sinewave(uranusPeriod)*uranus));

                    }
                
            
                myUranusFiltered = myFilter.hires(myUranus, 0.6,10.0);

        //OSCILLATOR Neptune

                if (neptuneStatus == 1){//Neptune ARIES
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*aries)) + sign.sinewave(aries+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
                if (neptuneStatus == 2){//Neptune TAURUS
                        
                    myNeptune=planet.sinewave(neptune+(sign.sinewave(neptunePeriod)*taurus));
                    
                    }

                if (neptuneStatus == 3){//Neptune GEMINI
                        
                    myNeptune=planet.sinewave(neptune+(sign.sinewave(neptunePeriod)*gemini)) + sign.sinewave(gemini+(planet.sinewave(neptunePeriod)*neptune));
                    }
                
                if (neptuneStatus == 4){//Neptune CANCER
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*cancer)) + sign.sinewave(cancer+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
                if (neptuneStatus == 5){//Neptune LEO
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*leo)) + sign.sinewave(leo+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
                if (neptuneStatus == 6){//Neptune VIRGO
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*virgo)) + sign.sinewave(virgo+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
                if (neptuneStatus == 7){//Neptune LIBRA
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*libra)) + sign.sinewave(libra+(period2.sinewave(neptunePeriod)*neptune));

                    }
            
                if (neptuneStatus == 8){//Neptune SCORPIO
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*scorpio)) + sign.sinewave(scorpio+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
                if (neptuneStatus == 9){//Neptune SAGITTARIUS
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*sagittarius)) + sign.sinewave(sagittarius+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
                if (neptuneStatus == 10){//Neptune CAPRICORN
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*capricorn)) + sign.sinewave(capricorn+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
                if (neptuneStatus == 11){//Neptune AQUARIUS
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*aquarius)) + sign.sinewave(aquarius+(period2.sinewave(neptunePeriod)*neptune));

                    }
            
                
                
                if (neptuneStatus == 12){//Neptune PIECES
                        
                    myNeptune=planet.sinewave(neptune+(period.sinewave(neptunePeriod)*pieces)) + sign.sinewave(pieces+(period2.sinewave(neptunePeriod)*neptune));

                    }
                
        myNeptuneFiltered = myFilter.hires(myNeptune, 0.6,10.0);

        //SOUNDOUT
        buffer[i*buffer.getNumChannels()    ]=  myMercuryFiltered + myVenusFiltered +  myMarsFiltered + mySaturnFiltered + myUranusFiltered + myNeptuneFiltered;
        buffer[i*buffer.getNumChannels() + 1]=   myMercuryFiltered + myVenusFiltered +  myMarsFiltered + mySaturnFiltered + myUranusFiltered + myNeptuneFiltered;

//
//
//        buffer[i*buffer.getNumChannels()    ]=  myMarsFiltered;
//        buffer[i*buffer.getNumChannels() + 1]=   myMarsFiltered;
//
//        buffer[i*buffer.getNumChannels()    ]=  myJupiterFiltered;
//        buffer[i*buffer.getNumChannels() + 1]=   myJupiterFiltered;
//
//
        

        
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y  ){

}


//MERCURY button PRESS
void ofApp::mercuryAriesPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 1;
    cout << "mercury in aries" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryTaurusPressed() {
    // Add your desired functionality for Button B here
    mercuryStatus = 2;
    cout << "mercury in taurus!" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryGeminiPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 3;
    cout << "mercury in gemini" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryCancerPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 4;
    cout << "mercury in cancer" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryLeoPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 5;
    cout << "mercury in leo" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryVirgoPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 6;
    cout << "mercury in virgo" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryLibraPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 7;
    cout << "mercury in libra" << endl;
    cout << mercuryStatus << endl;
}


void ofApp::mercuryScorpioPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 8;
    cout << "mercury in scorpio" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercurySagitariusPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 9;
    cout << "mercury in sagitarius" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryCapricornPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 10;
    cout << "mercury in ariescapricorn" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryAquariusPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 11;
    cout << "mercury in aquarius" << endl;
    cout << mercuryStatus << endl;
}

void ofApp::mercuryPiecesPressed() {
    // Add your desired functionality for Button A here
    mercuryStatus = 12;
    cout << "mercury in pieces" << endl;
    cout << mercuryStatus << endl;
}


//VENUS PRESSED
void ofApp::venusAriesPressed() {
    // Add your desired functionality for Button A here
    venusStatus = 1;
    cout << "venus in aries" << endl;
    cout << venusStatus << endl;
}

void ofApp::venusTaurusPressed() {
    // Add your desired functionality for Button B here
    venusStatus = 2;
    cout << "venus in taurus!" << endl;
    cout << venusStatus << endl;
}

void ofApp::venusGeminiPressed() {
    // Add your desired functionality for Button A here
    venusStatus = 3;
    cout << "venus in gemini" << endl;
    cout << venusStatus << endl;
}

void ofApp::venusCancerPressed() {
    // Add your desired functionality for Button A here
    venusStatus = 4;
    cout << "venus in cancer" << endl;
    cout << venusStatus << endl;
}

void ofApp::venusLeoPressed() {
    // Add your desired functionality for Button A here
    venusStatus = 5;
    cout << "venus in leo" << endl;
    cout << venusStatus << endl;
}

void ofApp::venusVirgoPressed() {
    // Add your desired functionality for Button A here
    venusStatus = 6;
    cout << "venus in virgo" << endl;
    cout << venusStatus << endl;
}

void ofApp::venusLibraPressed() {
    // Add your desired functionality for Button A here
    venusStatus = 7;
    cout << "venus in libra" << endl;
    cout << venusStatus << endl;
}

//MARS button PRESS FUNCTION
void ofApp::marsAriesPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 1;
    cout << "mars in aries" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsTaurusPressed() {
    // Add your desired functionality for Button B here
    marsStatus = 2;
    cout << "mars in taurus!" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsGeminiPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 3;
    cout << "mars in gemini" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsCancerPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 4;
    cout << "mars in cancer" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsLeoPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 5;
    cout << "mars in leo" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsVirgoPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 6;
    cout << "mars in virgo" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsLibraPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 7;
    cout << "mars in libra" << endl;
    cout << marsStatus << endl;
}


void ofApp::marsScorpioPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 8;
    cout << "mars in scorpio" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsSagitariusPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 9;
    cout << "mars in sagitarius" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsCapricornPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 10;
    cout << "mars in ariescapricorn" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsAquariusPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 11;
    cout << "mars in aquarius" << endl;
    cout << marsStatus << endl;
}

void ofApp::marsPiecesPressed() {
    // Add your desired functionality for Button A here
    marsStatus = 12;
    cout << "mars in pieces" << endl;
    cout << marsStatus << endl;
}

//BUTTON PRESSED FUNCTION JUPITER
void ofApp::jupiterAriesPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 1;
    cout << "jupiter in aries" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterTaurusPressed() {
    // Add your desired functionality for Button B here
    jupiterStatus = 2;
    cout << "jupiter in taurus!" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterGeminiPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 3;
    cout << "jupiter in gemini" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterCancerPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 4;
    cout << "jupiter in cancer" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterLeoPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 5;
    cout << "jupiter in leo" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterVirgoPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 6;
    cout << "jupiter in virgo" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterLibraPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 7;
    cout << "jupiter in libra" << endl;
    cout << jupiterStatus << endl;
}


void ofApp::jupiterScorpioPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 8;
    cout << "jupiter in scorpio" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterSagitariusPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 9;
    cout << "jupiter in sagitarius" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterCapricornPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 10;
    cout << "jupiter in ariescapricorn" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterAquariusPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 11;
    cout << "jupiter in aquarius" << endl;
    cout << jupiterStatus << endl;
}

void ofApp::jupiterPiecesPressed() {
    // Add your desired functionality for Button A here
    jupiterStatus = 12;
    cout << "jupiter in pieces" << endl;
    cout << jupiterStatus << endl;
}

//SATURN BUTTON FUNCTION
//BUTTON PRESSED FUNCTION
void ofApp::saturnAriesPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 1;
    cout << "saturn in aries" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnTaurusPressed() {
    // Add your desired functionality for Button B here
    saturnStatus = 2;
    cout << "saturn in taurus!" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnGeminiPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 3;
    cout << "saturn in gemini" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnCancerPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 4;
    cout << "saturn in cancer" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnLeoPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 5;
    cout << "saturn in leo" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnVirgoPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 6;
    cout << "saturn in virgo" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnLibraPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 7;
    cout << "saturn in libra" << endl;
    cout << saturnStatus << endl;
}


void ofApp::saturnScorpioPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 8;
    cout << "saturn in scorpio" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnSagitariusPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 9;
    cout << "saturn in sagitarius" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnCapricornPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 10;
    cout << "saturn in ariescapricorn" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnAquariusPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 11;
    cout << "saturn in aquarius" << endl;
    cout << saturnStatus << endl;
}

void ofApp::saturnPiecesPressed() {
    // Add your desired functionality for Button A here
    saturnStatus = 12;
    cout << "saturn in pieces" << endl;
    cout << saturnStatus << endl;
}


//SATURN BUTTON FUNCTIONS
//BUTTON PRESSED FUNCTION
void ofApp::uranusAriesPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 1;
    cout << "uranus in aries" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusTaurusPressed() {
    // Add your desired functionality for Button B here
    uranusStatus = 2;
    cout << "uranus in taurus!" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusGeminiPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 3;
    cout << "uranus in gemini" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusCancerPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 4;
    cout << "uranus in cancer" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusLeoPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 5;
    cout << "uranus in leo" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusVirgoPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 6;
    cout << "uranus in virgo" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusLibraPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 7;
    cout << "uranus in libra" << endl;
    cout << uranusStatus << endl;
}


void ofApp::uranusScorpioPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 8;
    cout << "uranus in scorpio" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusSagitariusPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 9;
    cout << "uranus in sagitarius" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusCapricornPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 10;
    cout << "uranus in ariescapricorn" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusAquariusPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 11;
    cout << "uranus in aquarius" << endl;
    cout << uranusStatus << endl;
}

void ofApp::uranusPiecesPressed() {
    // Add your desired functionality for Button A here
    uranusStatus = 12;
    cout << "uranus in pieces" << endl;
    cout << uranusStatus << endl;
}

//BUTTON PRESSED FUNCTION
void ofApp::neptuneAriesPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 1;
    cout << "neptune in aries" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneTaurusPressed() {
    // Add your desired functionality for Button B here
    neptuneStatus = 2;
    cout << "neptune in taurus!" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneGeminiPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 3;
    cout << "neptune in gemini" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneCancerPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 4;
    cout << "neptune in cancer" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneLeoPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 5;
    cout << "neptune in leo" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneVirgoPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 6;
    cout << "neptune in virgo" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneLibraPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 7;
    cout << "neptune in libra" << endl;
    cout << neptuneStatus << endl;
}


void ofApp::neptuneScorpioPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 8;
    cout << "neptune in scorpio" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneSagitariusPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 9;
    cout << "neptune in sagitarius" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneCapricornPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 10;
    cout << "neptune in ariescapricorn" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptuneAquariusPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 11;
    cout << "neptune in aquarius" << endl;
    cout << neptuneStatus << endl;
}

void ofApp::neptunePiecesPressed() {
    // Add your desired functionality for Button A here
    neptuneStatus = 12;
    cout << "neptune in pieces" << endl;
    cout << neptuneStatus << endl;
}



//
//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
    if (button == 1){
        col = ofRandom(20,100);
        //ofDrawRectangle(10, 10, 20, 20);
        }
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
    if (button == 1){
        col = ofRandom(20,100);
        //ofDrawRectangle(10, 10, 20, 20);
        }
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){

}
