#pragma once

#include "ofMain.h"
#include "ofxMaxim.h"
#include "ofxGui.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);


        // Audio output and input methods
        void exit();
        void audioOut(ofSoundBuffer & buffer);
        ofSoundStreamSettings soundSettings;
        ofSoundStream soundStream;
        int sampleRate;
        int bufferSize;
        maxiOsc osc1;
    
    

    maxiOsc planet;
    maxiOsc sign;
    

    maxiEnv ADSR;
    
    
    //TIMER
    int tim;
    maxiClock myClock;
    

    
    //PLANET FREQUENCIES
    int sun;
    int moon;
    int mercury = 293;
    int venus = 440;
    int mars = 277;
    int jupiter = 369;
    int saturn = 293;
    int uranus = 415;
    int neptune = 415;

    //PLANET PERIOD
    float mercuryPeriod = 1;
    float venusPeriod = 0.5;
    float marsPeriod = 0.33;
    float jupiterPeriod = 0.083;
    float saturnPeriod = 0.05;
    float uranusPeriod = 0.033;
    float neptunePeriod = 0.016;


    //SIGHNS FREQUENCY
    int  aries = 261;
    int  taurus = 392;
    int  gemini = 293;
    int  cancer = 440;
    int  leo = 329;
    int  virgo = 493;
    int  libra = 369;
    int  scorpio = 277;
    int  sagittarius = 415;
    int  capricorn = 311;
    int  aquarius = 466;
    int  pieces = 349;

    
    int col;
    
    //GUI PANELS
    ofxPanel gui;
    ofxPanel gui2;
    ofxPanel gui3;
    ofxPanel gui4;
    ofxPanel gui5;
    ofxPanel gui6;
    ofxPanel gui7;

    
    //BUTTONS FOR MERCURY
    ofxButton mercuryAries;
    ofxButton mercuryTaurus;
    ofxButton mercuryGemini;
    ofxButton mercuryCancer;
    ofxButton mercuryLeo;
    ofxButton mercuryVirgo;
    ofxButton mercuryLibra;
    ofxButton mercuryScorpio;
    ofxButton mercurySagittarius;
    ofxButton mercuryCapricorn;
    ofxButton mercuryAquarius;
    ofxButton mercuryPieces;
    void mercuryAriesPressed();
    void mercuryTaurusPressed();
    void mercuryGeminiPressed();
    void mercuryCancerPressed();
    void mercuryLeoPressed();
    void mercuryVirgoPressed();
    void mercuryLibraPressed();
    void mercuryScorpioPressed();
    void mercurySagitariusPressed();
    void mercuryCapricornPressed();
    void mercuryAquariusPressed();
    void mercuryPiecesPressed();
    
    //BUTTONS FOR VENUS
    ofxButton venusAries;
      ofxButton venusTaurus;
      ofxButton venusGemini;
      ofxButton venusCancer;
      ofxButton venusLeo;
      ofxButton venusVirgo;
      ofxButton venusLibra;
      ofxButton venusScorpio;
      ofxButton venusSagittarius;
      ofxButton venusCapricorn;
      ofxButton venusAquarius;
      ofxButton venusPieces;
      void venusAriesPressed();
      void venusTaurusPressed();
      void venusGeminiPressed();
      void venusCancerPressed();
      void venusLeoPressed();
      void venusVirgoPressed();
      void venusLibraPressed();
      void venusScorpioPressed();
      void venusSagitariusPressed();
      void venusCapricornPressed();
      void venusAquariusPressed();
      void venusPiecesPressed();
    
    //BUTTONS FOR MARS
    ofxButton marsAries;
      ofxButton marsTaurus;
      ofxButton marsGemini;
      ofxButton marsCancer;
      ofxButton marsLeo;
      ofxButton marsVirgo;
      ofxButton marsLibra;
      ofxButton marsScorpio;
      ofxButton marsSagittarius;
      ofxButton marsCapricorn;
      ofxButton marsAquarius;
      ofxButton marsPieces;
      void marsAriesPressed();
      void marsTaurusPressed();
      void marsGeminiPressed();
      void marsCancerPressed();
      void marsLeoPressed();
      void marsVirgoPressed();
      void marsLibraPressed();
      void marsScorpioPressed();
      void marsSagitariusPressed();
      void marsCapricornPressed();
      void marsAquariusPressed();
      void marsPiecesPressed();
    
    //BUTTONS FOR JUPITER
      ofxButton jupiterAries;
        ofxButton jupiterTaurus;
        ofxButton jupiterGemini;
        ofxButton jupiterCancer;
        ofxButton jupiterLeo;
        ofxButton jupiterVirgo;
        ofxButton jupiterLibra;
        ofxButton jupiterScorpio;
        ofxButton jupiterSagittarius;
        ofxButton jupiterCapricorn;
        ofxButton jupiterAquarius;
        ofxButton jupiterPieces;
        void jupiterAriesPressed();
        void jupiterTaurusPressed();
        void jupiterGeminiPressed();
        void jupiterCancerPressed();
        void jupiterLeoPressed();
        void jupiterVirgoPressed();
        void jupiterLibraPressed();
        void jupiterScorpioPressed();
        void jupiterSagitariusPressed();
        void jupiterCapricornPressed();
        void jupiterAquariusPressed();
        void jupiterPiecesPressed();
    
    
    //BUTTON VARIABLES SATURN
      ofxButton saturnAries;
        ofxButton saturnTaurus;
        ofxButton saturnGemini;
        ofxButton saturnCancer;
        ofxButton saturnLeo;
        ofxButton saturnVirgo;
        ofxButton saturnLibra;
        ofxButton saturnScorpio;
        ofxButton saturnSagittarius;
        ofxButton saturnCapricorn;
        ofxButton saturnAquarius;
        ofxButton saturnPieces;
        void saturnAriesPressed();
        void saturnTaurusPressed();
        void saturnGeminiPressed();
        void saturnCancerPressed();
        void saturnLeoPressed();
        void saturnVirgoPressed();
        void saturnLibraPressed();
        void saturnScorpioPressed();
        void saturnSagitariusPressed();
        void saturnCapricornPressed();
        void saturnAquariusPressed();
        void saturnPiecesPressed();
    
    //uranus BOTTONS
    ofxButton uranusAries;
       ofxButton uranusTaurus;
       ofxButton uranusGemini;
       ofxButton uranusCancer;
       ofxButton uranusLeo;
       ofxButton uranusVirgo;
       ofxButton uranusLibra;
       ofxButton uranusScorpio;
       ofxButton uranusSagittarius;
       ofxButton uranusCapricorn;
       ofxButton uranusAquarius;
       ofxButton uranusPieces;
       void uranusAriesPressed();
       void uranusTaurusPressed();
       void uranusGeminiPressed();
       void uranusCancerPressed();
       void uranusLeoPressed();
       void uranusVirgoPressed();
       void uranusLibraPressed();
       void uranusScorpioPressed();
       void uranusSagitariusPressed();
       void uranusCapricornPressed();
       void uranusAquariusPressed();
       void uranusPiecesPressed();

    //BUTTON VARIABLES neptune
      ofxButton neptuneAries;
        ofxButton neptuneTaurus;
        ofxButton neptuneGemini;
        ofxButton neptuneCancer;
        ofxButton neptuneLeo;
        ofxButton neptuneVirgo;
        ofxButton neptuneLibra;
        ofxButton neptuneScorpio;
        ofxButton neptuneSagittarius;
        ofxButton neptuneCapricorn;
        ofxButton neptuneAquarius;
        ofxButton neptunePieces;
        void neptuneAriesPressed();
        void neptuneTaurusPressed();
        void neptuneGeminiPressed();
        void neptuneCancerPressed();
        void neptuneLeoPressed();
        void neptuneVirgoPressed();
        void neptuneLibraPressed();
        void neptuneScorpioPressed();
        void neptuneSagitariusPressed();
        void neptuneCapricornPressed();
        void neptuneAquariusPressed();
        void neptunePiecesPressed();


    
    //BUTTON STATUS
   int mercuryStatus;
    int venusStatus;
    int marsStatus;
     int jupiterStatus;
    int saturnStatus;
     int uranusStatus;
    int neptuneStatus;

    
    maxiOsc period;
    maxiOsc period2;
    
    
  
    
    maxiFilter myFilter;
    
};
